import React, { useState } from 'react';
import { CheckCircle2, XCircle, HelpCircle, ArrowLeft, BookOpen, Scale, Search, ShieldCheck } from 'lucide-react';
import { UPAQuestion, UserAnswerState } from '../types/quiz';
import { soundEffects } from '../utils/soundEffects';

interface ReviewModalProps {
  questions: UPAQuestion[];
  answers: Record<number, UserAnswerState>;
  onClose: () => void;
}

export const ReviewModal: React.FC<ReviewModalProps> = ({
  questions,
  answers,
  onClose,
}) => {
  const [filter, setFilter] = useState<'all' | 'wrong' | 'doubtful' | 'correct'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredQuestions = questions.filter((q, index) => {
    const ans = answers[index];
    const isCorrect = ans?.selectedOption === q.correctAnswer;
    const isAnswered = ans?.selectedOption !== null && ans?.selectedOption !== undefined;
    const isDoubtful = ans?.isDoubtful;

    if (filter === 'wrong' && (!isAnswered || isCorrect)) return false;
    if (filter === 'correct' && !isCorrect) return false;
    if (filter === 'doubtful' && !isDoubtful) return false;

    if (searchQuery.trim()) {
      const qText = (q.question + ' ' + q.explanation.legalBasis + ' ' + q.explanation.analysis + ' ' + q.category).toLowerCase();
      if (!qText.includes(searchQuery.toLowerCase())) return false;
    }

    return true;
  });

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <button
            onClick={() => {
              soundEffects.playClick();
              onClose();
            }}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white mb-2 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Kembali ke Ringkasan Hasil</span>
          </button>
          <h2 className="text-xl sm:text-2xl font-bold font-legal text-slate-900 dark:text-white">
            Lembar Pembahasan Yuridis Mendalam
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Ulasan yuridis komprehensif dilengkapi dengan dasar hukum konkrit (Pasal HIR, KUHAP, UU PTUN, KEAI, UU MK).
          </p>
        </div>

        {/* Filter Tab Buttons */}
        <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
          <button
            onClick={() => {
              soundEffects.playClick();
              setFilter('all');
            }}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
              filter === 'all'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            Semua ({questions.length})
          </button>
          <button
            onClick={() => {
              soundEffects.playClick();
              setFilter('wrong');
            }}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
              filter === 'wrong'
                ? 'bg-rose-500 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            Salah Saja
          </button>
          <button
            onClick={() => {
              soundEffects.playClick();
              setFilter('doubtful');
            }}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
              filter === 'doubtful'
                ? 'bg-amber-500 text-slate-950 font-semibold shadow-xs'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            Ragu-Ragu
          </button>
          <button
            onClick={() => {
              soundEffects.playClick();
              setFilter('correct');
            }}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
              filter === 'correct'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            Benar
          </button>
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Cari kata kunci, topik, atau pasal (contoh: Pasal 118, praperadilan, verzet, KEAI)..."
          className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500 shadow-xs"
        />
      </div>

      {/* Question Cards List */}
      <div className="space-y-6">
        {filteredQuestions.length === 0 ? (
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-12 text-center text-slate-500">
            Tidak ada soal yang cocok dengan filter atau pencarian Anda.
          </div>
        ) : (
          filteredQuestions.map((q) => {
            const originalIndex = questions.findIndex((item) => item.id === q.id);
            const ans = answers[originalIndex];
            const isCorrect = ans?.selectedOption === q.correctAnswer;
            const isAnswered = ans?.selectedOption !== null && ans?.selectedOption !== undefined;
            const isDoubtful = ans?.isDoubtful;

            return (
              <div
                key={q.id}
                className={`bg-white dark:bg-slate-900 border rounded-2xl p-6 sm:p-8 shadow-sm transition-colors ${
                  !isAnswered
                    ? 'border-slate-200 dark:border-slate-800'
                    : isCorrect
                    ? 'border-emerald-200 dark:border-emerald-900/60'
                    : 'border-rose-200 dark:border-rose-900/60'
                }`}
              >
                {/* Meta unboxed */}
                <div className="flex flex-wrap items-center justify-between gap-2 pb-3 mb-4 border-b border-slate-100 dark:border-slate-800/80 text-xs">
                  <div className="flex items-center gap-2 text-slate-500 dark:text-slate-400">
                    <span className="font-semibold text-slate-900 dark:text-white">
                      Soal No. {originalIndex + 1}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="text-amber-700 dark:text-amber-400 font-medium">
                      {q.category}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{q.topicTag}</span>
                  </div>

                  {/* Status Indicator */}
                  <div className="flex items-center gap-2 font-medium">
                    {isDoubtful && (
                      <span className="inline-flex items-center gap-1 text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/60 px-2 py-0.5 rounded text-[11px]">
                        <HelpCircle className="w-3 h-3" />
                        Ragu-ragu
                      </span>
                    )}

                    {!isAnswered ? (
                      <span className="text-slate-500 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded text-[11px]">
                        Tidak Dijawab
                      </span>
                    ) : isCorrect ? (
                      <span className="inline-flex items-center gap-1 text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded text-[11px]">
                        <CheckCircle2 className="w-3 h-3" />
                        Jawaban Anda Benar
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-rose-700 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/60 px-2 py-0.5 rounded text-[11px]">
                        <XCircle className="w-3 h-3" />
                        Jawaban Anda Salah
                      </span>
                    )}
                  </div>
                </div>

                {/* Question */}
                <h3 className="text-sm sm:text-base font-semibold text-slate-900 dark:text-slate-100 mb-4 leading-relaxed">
                  {q.question}
                </h3>

                {/* Options List */}
                <div className="space-y-2 mb-6">
                  {q.options.map((opt) => {
                    const isKey = opt.key === q.correctAnswer;
                    const isUserChoice = ans?.selectedOption === opt.key;

                    let optClass = 'p-3 rounded-xl border text-xs sm:text-sm flex items-start gap-3 ';
                    if (isKey) {
                      optClass += 'bg-emerald-50/80 dark:bg-emerald-950/40 border-emerald-400 dark:border-emerald-700 text-emerald-950 dark:text-emerald-100 font-medium';
                    } else if (isUserChoice && !isCorrect) {
                      optClass += 'bg-rose-50/80 dark:bg-rose-950/40 border-rose-400 dark:border-rose-700 text-rose-950 dark:text-rose-100';
                    } else {
                      optClass += 'border-slate-200 dark:border-slate-800/80 bg-slate-50/40 dark:bg-slate-800/20 text-slate-700 dark:text-slate-300';
                    }

                    return (
                      <div key={opt.key} className={optClass}>
                        <span
                          className={`w-6 h-6 rounded flex items-center justify-center font-mono font-bold text-xs shrink-0 ${
                            isKey
                              ? 'bg-emerald-600 text-white'
                              : isUserChoice
                              ? 'bg-rose-600 text-white'
                              : 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                          }`}
                        >
                          {opt.key}
                        </span>
                        <div className="flex-1 pt-0.5">
                          <span>{opt.text}</span>
                          {isKey && (
                            <span className="ml-2 font-bold text-[11px] text-emerald-700 dark:text-emerald-400">
                              (KUNCI JAWABAN BENAR)
                            </span>
                          )}
                          {isUserChoice && !isCorrect && (
                            <span className="ml-2 font-bold text-[11px] text-rose-700 dark:text-rose-400">
                              (PILIHAN ANDA)
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Detailed Legal Review Box */}
                <div className="p-5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-3">
                  {/* Concrete Statutory Legal Basis */}
                  <div className="flex items-start gap-2.5">
                    <Scale className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <span className="text-[11px] font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400 block mb-0.5">
                        Dasar Hukum Konkrit
                      </span>
                      <p className="text-xs sm:text-sm font-semibold font-mono text-slate-900 dark:text-white">
                        {q.explanation.legalBasis}
                      </p>
                    </div>
                  </div>

                  {/* Legal Summary / Rationale */}
                  <div className="pt-2 border-t border-slate-200 dark:border-slate-700">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 block mb-0.5">
                      Alasan Hukum Mengapa Benar
                    </span>
                    <p className="text-xs sm:text-sm text-slate-800 dark:text-slate-200 leading-relaxed font-medium">
                      {q.explanation.summary}
                    </p>
                  </div>

                  {/* Comprehensive Juridical Analysis */}
                  <div className="pt-2 border-t border-slate-200 dark:border-slate-700">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 block mb-0.5">
                      Analisis Yuridis & Penerapan Kasus
                    </span>
                    <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                      {q.explanation.analysis}
                    </p>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
