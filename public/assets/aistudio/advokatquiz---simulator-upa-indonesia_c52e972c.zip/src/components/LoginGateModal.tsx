import React, { useState } from 'react';
import { Scale, Mail, User, Shield, ArrowRight, Lock, CheckCircle2 } from 'lucide-react';
import { userService } from '../services/userService';
import { UserProfile } from '../types/auth';
import { soundEffects } from '../utils/soundEffects';

interface LoginGateModalProps {
  onLoginSuccess: (user: UserProfile) => void;
}

export const LoginGateModal: React.FC<LoginGateModalProps> = ({ onLoginSuccess }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [organization, setOrganization] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !name.trim()) {
      setErrorMsg('Mohon lengkapi nama dan alamat email Anda.');
      return;
    }

    soundEffects.playClick();
    const user = userService.login(name, email, organization);
    onLoginSuccess(user);
  };

  const handleQuickLoginAdmin = () => {
    soundEffects.playClick();
    const user = userService.login(
      'Administrator / Pengawas UPA',
      'amifaveiro9@gmail.com',
      'DPN PERADI / Tim Penguji UPA'
    );
    onLoginSuccess(user);
  };

  const handleQuickLoginFriend = () => {
    soundEffects.playClick();
    const friendNames = [
      'Budi Santoso, S.H.',
      'Siti Rahmania, S.H.',
      'Fajar Nugraha, S.H.',
      'Amanda Pratiwi, S.H.'
    ];
    const pickedName = friendNames[Math.floor(Math.random() * friendNames.length)];
    const cleanMail = pickedName.toLowerCase().replace(/[^a-z]/g, '') + '@gmail.com';
    const user = userService.login(
      pickedName,
      cleanMail,
      'PKPA PERADI Angkatan 2026'
    );
    onLoginSuccess(user);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-2xl relative overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Decorative Top Accent */}
        <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-amber-600 via-amber-500 to-amber-700" />

        {/* Branding Crest */}
        <div className="text-center space-y-3 mb-6">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-600 to-amber-800 text-white shadow-md shadow-amber-950/20 mx-auto">
            <Scale className="w-7 h-7 text-amber-100" />
          </div>
          <div>
            <h1 className="text-2xl font-bold font-legal text-slate-900 dark:text-white tracking-tight">
              Advokat<span className="text-amber-600 dark:text-amber-500">Quiz</span>
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Portal Akses Simulasi Ujian Profesi Advokat Indonesia
            </p>
          </div>
        </div>

        {/* Info Banner */}
        <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-300 flex items-start gap-2.5 mb-5">
          <Lock className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
          <p className="leading-relaxed">
            Silakan masukkan email Anda untuk masuk. Data pengerjaan dan skor Anda akan dicatat dalam riwayat bersama pengawas/rekan seangkatan.
          </p>
        </div>

        {errorMsg && (
          <div className="p-3 rounded-lg bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900 text-xs text-rose-600 dark:text-rose-400 mb-4">
            {errorMsg}
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Alamat Email Aktif <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="nama.anda@gmail.com"
                className="w-full text-xs sm:text-sm pl-9 pr-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Nama Lengkap & Gelar <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <User className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Contoh: Rian Pratama, S.H."
                className="w-full text-xs sm:text-sm pl-9 pr-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Asal Angkatan / Organisasi (Opsional)
            </label>
            <input
              type="text"
              value={organization}
              onChange={(e) => setOrganization(e.target.value)}
              placeholder="Contoh: PKPA PERADI Batch 2026"
              className="w-full text-xs sm:text-sm px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
          </div>

          <button
            type="submit"
            className="w-full py-3 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 dark:bg-amber-600 dark:hover:bg-amber-500 rounded-xl transition-all shadow-md flex items-center justify-center gap-2 mt-2"
          >
            <span>Masuk ke Aplikasi</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        {/* Quick Testing Short-cuts */}
        <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 text-center space-y-2">
          <span className="text-[11px] text-slate-400 dark:text-slate-500 block">
            Pintasan Uji Coba Cepat:
          </span>
          <div className="flex flex-col sm:flex-row gap-2">
            <button
              type="button"
              onClick={handleQuickLoginAdmin}
              className="flex-1 py-1.5 px-2 text-[11px] font-semibold rounded-lg border border-amber-300 dark:border-amber-800/80 bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300 hover:bg-amber-100 transition-colors"
            >
              Masuk sbg Admin (amifaveiro9@gmail.com)
            </button>
            <button
              type="button"
              onClick={handleQuickLoginFriend}
              className="flex-1 py-1.5 px-2 text-[11px] font-semibold rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 transition-colors"
            >
              Masuk sbg Rekan Belajar
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
