import React, { useState, useEffect } from 'react';
import { Users, Copy, Check, Play, UserPlus, Shield, Sparkles, AlertCircle, Clock, Zap } from 'lucide-react';
import { RoomSettings, Participant, TimerMode, UPACategory, RoomChatMessage } from '../types/quiz';
import { RoomLiveChat } from './RoomLiveChat';
import { generateRoomCode } from '../utils/seededRandom';
import { soundEffects } from '../utils/soundEffects';

interface MultiplayerLobbyProps {
  currentRoom: RoomSettings | null;
  participants: Participant[];
  currentUser: Participant | null;
  onCreateRoom: (settings: RoomSettings, hostName: string) => void;
  onJoinRoom: (code: string, userName: string) => void;
  onStartExam: () => void;
  onLeaveRoom: () => void;
  onToggleAiBuddies: (enabled: boolean) => void;
  aiBuddiesEnabled: boolean;
  roomMessages: RoomChatMessage[];
  onSendMessage: (message: string) => void;
}

export const MultiplayerLobby: React.FC<MultiplayerLobbyProps> = ({
  currentRoom,
  participants,
  currentUser,
  onCreateRoom,
  onJoinRoom,
  onStartExam,
  onLeaveRoom,
  onToggleAiBuddies,
  aiBuddiesEnabled,
  roomMessages,
  onSendMessage,
}) => {
  const [activeTab, setActiveTab] = useState<'create' | 'join'>('create');
  const [copied, setCopied] = useState(false);

  // Form states for Create
  const [hostName, setHostName] = useState('Calon Advokat ' + Math.floor(Math.random() * 900 + 100));
  const [roomName, setRoomName] = useState('Latihan Bersama UPA 2026');
  const [questionCount, setQuestionCount] = useState<number>(20);
  const [timerMode, setTimerMode] = useState<TimerMode>('official');
  const [flashSeconds, setFlashSeconds] = useState<number>(60);
  const [officialMinutes, setOfficialMinutes] = useState<number>(30);
  const [categoryFilter, setCategoryFilter] = useState<UPACategory | 'Semua Materi'>('Semua Materi');

  // Form states for Join
  const [joinCode, setJoinCode] = useState('');
  const [guestName, setGuestName] = useState('');

  const handleCopyCode = () => {
    if (!currentRoom) return;
    navigator.clipboard.writeText(currentRoom.code);
    soundEffects.playClick();
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    soundEffects.playClick();
    const newCode = generateRoomCode();
    const settings: RoomSettings = {
      code: newCode,
      roomName: roomName.trim() || 'Ruang Latihan UPA',
      hostName: hostName.trim() || 'Host Advokat',
      questionCount,
      timerMode,
      categoryFilter,
      flashSecondsPerQuestion: flashSeconds,
      officialTotalMinutes: officialMinutes,
    };
    onCreateRoom(settings, hostName.trim() || 'Host Advokat');
  };

  const handleJoinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!joinCode.trim() || !guestName.trim()) return;
    soundEffects.playClick();
    onJoinRoom(joinCode.trim().toUpperCase(), guestName.trim());
  };

  // If already in a room, render Active Room Lobby
  if (currentRoom) {
    const isHost = currentUser?.isHost ?? false;

    return (
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left Column: Room Info & Participants */}
          <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-8 shadow-sm">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-slate-200 dark:border-slate-800">
              <div>
                <div className="flex items-center gap-2 text-xs text-amber-700 dark:text-amber-400 font-semibold mb-1">
                  <Users className="w-4 h-4" />
                  <span>Ruang Ujian Kolaboratif Aktif</span>
                </div>
                <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white font-legal tracking-tight">
                  {currentRoom.roomName}
                </h2>
                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mt-2">
                  <span>Materi: {currentRoom.categoryFilter}</span>
                  <span aria-hidden="true">·</span>
                  <span>Jumlah: {currentRoom.questionCount} Soal</span>
                  <span aria-hidden="true">·</span>
                  <span>
                    Mode Timer: {currentRoom.timerMode === 'official' ? `${currentRoom.officialTotalMinutes} Menit (Resmi)` : `${currentRoom.flashSecondsPerQuestion} Detik/Soal (Kilat)`}
                  </span>
                </div>
              </div>

              {/* Room Code Badge */}
              <div className="bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl p-4 flex flex-col items-center justify-center shrink-0">
                <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1">
                  Kode Akses Ruangan
                </span>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-2xl font-extrabold tracking-widest text-slate-900 dark:text-white">
                    {currentRoom.code}
                  </span>
                  <button
                    onClick={handleCopyCode}
                    className="p-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-white transition-colors"
                    title="Salin Kode Ruang"
                  >
                    {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
                <span className="text-[10px] text-slate-500 dark:text-slate-400 mt-1">
                  {copied ? 'Tersalin ke clipboard!' : 'Bagikan ke teman Anda'}
                </span>
              </div>
            </div>

            {/* Lobby Participant List */}
            <div className="mt-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                  <span>Peserta di Ruangan</span>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 font-mono text-slate-700 dark:text-slate-300">
                    {participants.length} Orang
                  </span>
                </h3>

                {/* Toggle Simulated Study Buddies */}
                <button
                  onClick={() => onToggleAiBuddies(!aiBuddiesEnabled)}
                  className={`text-xs px-3 py-1.5 rounded-lg border flex items-center gap-1.5 transition-colors ${
                    aiBuddiesEnabled
                      ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-300 dark:border-amber-800 text-amber-900 dark:text-amber-300'
                      : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                  }`}
                  title="Tambahkan rekan simulasi untuk latihan kompetisi instan"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                  <span>{aiBuddiesEnabled ? 'Simulasi Teman: Aktif' : '+ Tambah Teman Simulasi'}</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {participants.map((p) => {
                  const isMe = p.id === currentUser?.id;
                  return (
                    <div
                      key={p.id}
                      className={`p-3 rounded-xl border flex items-center gap-3 transition-colors ${
                        isMe
                          ? 'border-amber-500 bg-amber-50/50 dark:bg-amber-950/30'
                          : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/50'
                      }`}
                    >
                      <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-slate-700 to-slate-900 dark:from-slate-600 dark:to-slate-800 text-white font-mono font-bold text-xs flex items-center justify-center shrink-0 shadow-xs">
                        {p.name.slice(0, 2).toUpperCase()}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                            {p.name}
                          </span>
                          {p.isHost && (
                            <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 font-medium">
                              Host
                            </span>
                          )}
                        </div>
                        <span className="text-[11px] text-slate-500 dark:text-slate-400 block truncate">
                          {isMe ? 'Anda Sendiri' : 'Siap Ujian'}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Sync Notice */}
            <div className="mt-6 p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-300 flex items-start gap-3">
              <Shield className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-slate-900 dark:text-slate-100">
                  Sinkronisasi Soal & Timer Terjamin
                </p>
                <p className="mt-0.5 leading-relaxed text-slate-600 dark:text-slate-400">
                  Algoritma seeded generator memastikan seluruh peserta mendapatkan urutan soal dan pilihan jawaban yang identik secara serempak. Papan peringkat (leaderboard) akan diperbarui secara otomatis.
                </p>
              </div>
            </div>

            {/* Action Footer */}
            <div className="mt-6 pt-6 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-4">
              <button
                onClick={() => {
                  soundEffects.playClick();
                  onLeaveRoom();
                }}
                className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition-colors"
              >
                Tinggalkan Ruangan
              </button>

              {isHost ? (
                <button
                  onClick={() => {
                    soundEffects.playClick();
                    onStartExam();
                  }}
                  className="px-6 py-2.5 text-xs font-bold text-white bg-amber-600 hover:bg-amber-500 rounded-xl shadow-md flex items-center gap-2 transition-all"
                >
                  <Play className="w-4 h-4 fill-current" />
                  <span>Mulai Ujian Bersama Sekarang</span>
                </button>
              ) : (
                <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 font-medium">
                  <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse"></span>
                  <span>Menunggu Host memulai ujian...</span>
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Real-time Live Room Chat */}
          <div className="lg:col-span-5 sticky top-20">
            <RoomLiveChat
              roomCode={currentRoom.code}
              currentUser={currentUser}
              messages={roomMessages}
              onSendMessage={onSendMessage}
            />
          </div>
        </div>
      </div>
    );
  }

  // If not in a room, render Create / Join tabs
  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="text-center space-y-2 mb-6">
        <h2 className="text-2xl sm:text-3xl font-bold font-legal text-slate-900 dark:text-white">
          Ruang Ujian Kolaboratif
        </h2>
        <p className="text-sm text-slate-600 dark:text-slate-400 max-w-lg mx-auto">
          Mengerjakan simulasi soal UPA serempak bersama rekan seangkatan PKPA. Urutan soal tersinkronisasi 100% dengan papan peringkat interaktif di akhir sesi.
        </p>
      </div>

      {/* Segmented Tab Controls */}
      <div className="flex items-center p-1 bg-slate-100 dark:bg-slate-800 rounded-xl max-w-md mx-auto">
        <button
          onClick={() => {
            soundEffects.playClick();
            setActiveTab('create');
          }}
          className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-all ${
            activeTab === 'create'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          Bikin Ruang Baru
        </button>
        <button
          onClick={() => {
            soundEffects.playClick();
            setActiveTab('join');
          }}
          className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-all ${
            activeTab === 'join'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          Gabung Ruang Teman
        </button>
      </div>

      {/* Create Room Form */}
      {activeTab === 'create' && (
        <form
          onSubmit={handleCreateSubmit}
          className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-8 shadow-sm space-y-5"
        >
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Nama Anda (Host)
            </label>
            <input
              type="text"
              required
              value={hostName}
              onChange={(e) => setHostName(e.target.value)}
              placeholder="Contoh: Rian Pratama, S.H."
              className="w-full text-sm px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Nama Ruangan Latihan
            </label>
            <input
              type="text"
              required
              value={roomName}
              onChange={(e) => setRoomName(e.target.value)}
              placeholder="Contoh: Belajar Bareng DPC Jakarta"
              className="w-full text-sm px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Jumlah Soal
              </label>
              <select
                value={questionCount}
                onChange={(e) => setQuestionCount(Number(e.target.value))}
                className="w-full text-sm px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
              >
                <option value={10}>10 Soal (Latihan Cepat)</option>
                <option value={20}>20 Soal (Simulasi Standar)</option>
                <option value={50}>50 Soal (Paket Komprehensif)</option>
                <option value={100}>100 Soal (Tryout Penuh)</option>
                <option value={120}>120 Soal (Paket Try Out Naskah PDF)</option>
                <option value={500}>500 Soal (Master Database Pool)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Cakupan Materi
              </label>
              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value as UPACategory | 'Semua Materi')}
                className="w-full text-sm px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
              >
                <option value="Semua Materi">Semua Materi (Standar UPA)</option>
                <option value="Hukum Acara Perdata">Hukum Acara Perdata</option>
                <option value="Hukum Acara Pidana">Hukum Acara Pidana</option>
                <option value="Hukum Acara PTUN">Hukum Acara PTUN</option>
                <option value="Hukum Acara Peradilan Agama">Hukum Acara Peradilan Agama</option>
                <option value="Kode Etik Profesi Advokat">Kode Etik Profesi Advokat</option>
                <option value="Hukum Acara Mahkamah Konstitusi">Hukum Acara MK</option>
                <option value="Hukum Acara PHI">Hukum Acara PHI</option>
                <option value="Hukum Acara Arbitrase & APS">Hukum Acara Arbitrase & APS</option>
              </select>
            </div>
          </div>

          {/* Timer Settings */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
              Pengaturan Mode Pewaktu (Timer)
            </label>
            <div className="grid grid-cols-2 gap-3 mb-3">
              <button
                type="button"
                onClick={() => setTimerMode('official')}
                className={`p-3 rounded-xl border text-left transition-all ${
                  timerMode === 'official'
                    ? 'border-amber-600 bg-amber-50/70 dark:bg-amber-950/40 text-amber-950 dark:text-amber-100'
                    : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/40 text-slate-700 dark:text-slate-300'
                }`}
              >
                <div className="flex items-center gap-1.5 font-semibold text-xs mb-1">
                  <Clock className="w-3.5 h-3.5 text-amber-600" />
                  <span>Mode Ujian Resmi</span>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  Hitung mundur global untuk seluruh paket soal.
                </p>
              </button>

              <button
                type="button"
                onClick={() => setTimerMode('flash')}
                className={`p-3 rounded-xl border text-left transition-all ${
                  timerMode === 'flash'
                    ? 'border-amber-600 bg-amber-50/70 dark:bg-amber-950/40 text-amber-950 dark:text-amber-100'
                    : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/40 text-slate-700 dark:text-slate-300'
                }`}
              >
                <div className="flex items-center gap-1.5 font-semibold text-xs mb-1">
                  <Zap className="w-3.5 h-3.5 text-amber-600" />
                  <span>Mode Kilat / Soal</span>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  Waktu per soal (60-90 dtk). Otomatis lompat jika habis.
                </p>
              </button>
            </div>

            {timerMode === 'official' ? (
              <div className="flex items-center gap-3">
                <span className="text-xs text-slate-600 dark:text-slate-400">Durasi Total:</span>
                <div className="flex gap-2">
                  {[15, 30, 60, 90, 120].map((mins) => (
                    <button
                      key={mins}
                      type="button"
                      onClick={() => setOfficialMinutes(mins)}
                      className={`px-2.5 py-1 text-xs rounded-md font-mono ${
                        officialMinutes === mins
                          ? 'bg-amber-600 text-white font-bold'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {mins}m
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-3">
                <span className="text-xs text-slate-600 dark:text-slate-400">Waktu per Soal:</span>
                <div className="flex gap-2">
                  {[45, 60, 90, 120].map((secs) => (
                    <button
                      key={secs}
                      type="button"
                      onClick={() => setFlashSeconds(secs)}
                      className={`px-2.5 py-1 text-xs rounded-md font-mono ${
                        flashSeconds === secs
                          ? 'bg-amber-600 text-white font-bold'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {secs}d
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          <button
            type="submit"
            className="w-full py-3 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 dark:bg-amber-600 dark:hover:bg-amber-500 rounded-xl transition-all shadow-sm"
          >
            Buat Ruang Ujian & Dapatkan Kode Unik
          </button>
        </form>
      )}

      {/* Join Room Form */}
      {activeTab === 'join' && (
        <form
          onSubmit={handleJoinSubmit}
          className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-8 shadow-sm space-y-5"
        >
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Kode Unik Ruangan (Room Code)
            </label>
            <input
              type="text"
              required
              value={joinCode}
              onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
              placeholder="Contoh: UPA-ABC123"
              className="w-full text-base font-mono font-bold tracking-wider px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white uppercase focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
            <span className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 block">
              Dapatkan kode ini dari teman yang membuat ruangan.
            </span>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Nama Peserta Anda
            </label>
            <input
              type="text"
              required
              value={guestName}
              onChange={(e) => setGuestName(e.target.value)}
              placeholder="Contoh: Dewi Lestari, S.H."
              className="w-full text-sm px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
          </div>

          <button
            type="submit"
            className="w-full py-3 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 dark:bg-amber-600 dark:hover:bg-amber-500 rounded-xl transition-all shadow-sm flex items-center justify-center gap-2"
          >
            <UserPlus className="w-4 h-4" />
            <span>Gabung ke Ruang Ujian</span>
          </button>
        </form>
      )}
    </div>
  );
};
