/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Header } from './components/Header';
import { QuizSetup } from './components/QuizSetup';
import { QuestionCard } from './components/QuestionCard';
import { QuestionGrid } from './components/QuestionGrid';
import { TimerDisplay } from './components/TimerDisplay';
import { ResultDashboard } from './components/ResultDashboard';
import { ReviewModal } from './components/ReviewModal';
import { MultiplayerLobby } from './components/MultiplayerLobby';
import { QuestionBankModal } from './components/QuestionBankModal';
import { QuickCheatSheet } from './components/QuickCheatSheet';
import { PermanentSaveModal } from './components/PermanentSaveModal';

import {
  UPAQuestion,
  UserAnswerState,
  TimerMode,
  RoomSettings,
  Participant,
  QuizSessionSummary,
  QuestionOptionKey,
  UPACategory,
  RoomChatMessage,
} from './types/quiz';
import { UserProfile, QuestionResultItem } from './types/auth';
import { userService } from './services/userService';
import { LoginGateModal } from './components/LoginGateModal';
import { AdminMonitorView } from './components/AdminMonitorView';
import { RoomLiveChat } from './components/RoomLiveChat';
import { MASTER_UPA_DATABASE, UPA_CATEGORIES } from './data/upaQuestions';
import { shuffleWithSeed } from './utils/seededRandom';
import { soundEffects } from './utils/soundEffects';
import { LayoutGrid, X, Users, AlertCircle, MessageSquare } from 'lucide-react';

export default function App() {
  // Authentication / User Session State (Email Login required on first entry)
  const [authProfile, setAuthProfile] = useState<UserProfile | null>(() => {
    return userService.getCurrentUser();
  });
  const [onlineUserCount, setOnlineUserCount] = useState<number>(() => {
    return userService.getAllUsers().filter((u) => u.isOnline).length;
  });

  // Theme state
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('advokatquiz_dark') === 'true' ||
        window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return false;
  });

  // Sound state
  const [soundEnabled, setSoundEnabled] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('advokatquiz_sound') !== 'false';
    }
    return true;
  });

  // View state
  const [activeView, setActiveView] = useState<
    'home' | 'quiz' | 'multiplayer' | 'bank' | 'cheatsheet' | 'results' | 'review' | 'monitor'
  >('home');

  // Custom added questions
  const [customQuestions, setCustomQuestions] = useState<UPAQuestion[]>([]);

  // Active Quiz State
  const [quizQuestions, setQuizQuestions] = useState<UPAQuestion[]>([]);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [answers, setAnswers] = useState<Record<number, UserAnswerState>>({});
  const [timerMode, setTimerMode] = useState<TimerMode>('official');
  const [secondsRemaining, setSecondsRemaining] = useState<number>(0);
  const [totalSeconds, setTotalSeconds] = useState<number>(0);
  const [quizStartTime, setQuizStartTime] = useState<number>(0);
  const [quizSummary, setQuizSummary] = useState<QuizSessionSummary | null>(null);

  // Mobile drawer for Question Grid
  const [mobileGridOpen, setMobileGridOpen] = useState(false);

  // Permanent Save & Install Guide Modal
  const [saveModalOpen, setSaveModalOpen] = useState(false);

  // Multiplayer Room State
  const [currentRoom, setCurrentRoom] = useState<RoomSettings | null>(null);
  const [currentUser, setCurrentUser] = useState<Participant | null>(null);
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [aiBuddiesEnabled, setAiBuddiesEnabled] = useState<boolean>(true);
  const [roomMessages, setRoomMessages] = useState<RoomChatMessage[]>([]);
  const [chatModalOpen, setChatModalOpen] = useState<boolean>(false);

  // Sync with HTML class
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('advokatquiz_dark', 'true');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('advokatquiz_dark', 'false');
    }
  }, [darkMode]);

  useEffect(() => {
    soundEffects.enabled = soundEnabled;
    localStorage.setItem('advokatquiz_sound', String(soundEnabled));
  }, [soundEnabled]);

  // Real-time Presence & Activity Heartbeat
  useEffect(() => {
    if (!authProfile) return;

    const reportHeartbeat = () => {
      let activity = 'Di Beranda AdvokatQuiz';
      if (activeView === 'quiz') {
        const cat = quizQuestions[currentIndex]?.category || 'Materi UPA';
        activity = `Mengerjakan Soal ${currentIndex + 1}/${quizQuestions.length} (${cat})`;
      } else if (activeView === 'multiplayer') {
        activity = currentRoom ? `Di Ruang Belajar: ${currentRoom.roomName}` : 'Di Lobi Multiplayer';
      } else if (activeView === 'results') {
        activity = 'Melihat Ringkasan Skor & Evaluasi';
      } else if (activeView === 'review') {
        activity = 'Membaca Pembahasan Mendalam & Dasar Hukum';
      } else if (activeView === 'bank') {
        activity = 'Membuka Bank Data 500 Soal';
      } else if (activeView === 'cheatsheet') {
        activity = 'Menghafal Pasal-Pasal Kunci';
      } else if (activeView === 'monitor') {
        activity = 'Memantau Peserta Online & Riwayat';
      }

      userService.updateActivity(activity);
      const online = userService.getAllUsers().filter((u) => u.isOnline).length;
      setOnlineUserCount(online);
    };

    reportHeartbeat();
    const timer = setInterval(reportHeartbeat, 8000);

    // Listen to auth sync broadcast
    let bc: BroadcastChannel | null = null;
    if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
      bc = new BroadcastChannel('advokatquiz_auth_sync');
      bc.onmessage = () => {
        const online = userService.getAllUsers().filter((u) => u.isOnline).length;
        setOnlineUserCount(online);
      };
    }

    return () => {
      clearInterval(timer);
      if (bc) bc.close();
    };
  }, [authProfile, activeView, currentIndex, quizQuestions.length, currentRoom]);

  // BroadcastChannel for real-time cross-tab multiplayer sync
  const channelRef = useRef<BroadcastChannel | null>(null);

  useEffect(() => {
    if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
      const bc = new BroadcastChannel('advokatquiz_room_sync');
      channelRef.current = bc;

      bc.onmessage = (event) => {
        const { type, payload } = event.data;
        if (type === 'ROOM_JOIN' && currentRoom && payload.roomCode === currentRoom.code) {
          setParticipants((prev) => {
            if (prev.some((p) => p.id === payload.participant.id)) return prev;
            return [...prev, payload.participant];
          });
        } else if (type === 'START_EXAM' && currentRoom && payload.roomCode === currentRoom.code) {
          // Sync exam start
          startPreparedQuiz(payload.roomSettings, payload.seed);
        } else if (type === 'SCORE_UPDATE' && currentRoom && payload.roomCode === currentRoom.code) {
          setParticipants((prev) =>
            prev.map((p) =>
              p.id === payload.participantId
                ? {
                    ...p,
                    score: payload.score,
                    answeredCount: payload.answeredCount,
                    isFinished: payload.isFinished,
                    timeSpentSeconds: payload.timeSpentSeconds,
                  }
                : p
            )
          );
        } else if (type === 'CHAT_MESSAGE' && currentRoom && payload.roomCode === currentRoom.code) {
          setRoomMessages((prev) => {
            if (prev.some((m) => m.id === payload.message.id)) return prev;
            return [...prev, payload.message];
          });
          soundEffects.playClick();
        }
      };

      return () => {
        bc.close();
      };
    }
  }, [currentRoom]);

  // Simulated AI study peers progress ticker during active multiplayer quiz
  useEffect(() => {
    if (activeView !== 'quiz' || !currentRoom || !aiBuddiesEnabled) return;

    const interval = setInterval(() => {
      setParticipants((prev) =>
        prev.map((p) => {
          if (p.id === currentUser?.id || p.isFinished) return p;

          // Realistic simulated study buddy progress
          const currentTotal = quizQuestions.length;
          const newAnswered = Math.min(currentTotal, p.answeredCount + 1);
          // 75% probability of answering correctly for simulated legal colleagues
          const isCorrect = Math.random() < 0.75;
          const currentScore = (p.score / (p.answeredCount || 1)) * (p.answeredCount || 0);
          const newScore = ((currentScore + (isCorrect ? 100 / currentTotal : 0)));
          const finished = newAnswered >= currentTotal;

          return {
            ...p,
            answeredCount: newAnswered,
            score: Math.min(100, Math.round(newScore)),
            isFinished: finished,
            timeSpentSeconds: p.timeSpentSeconds + 4,
          };
        })
      );
    }, 4500);

    return () => clearInterval(interval);
  }, [activeView, currentRoom, aiBuddiesEnabled, currentUser?.id, quizQuestions.length]);

  // Main Timer ticker
  useEffect(() => {
    if (activeView !== 'quiz') return;

    const timer = setInterval(() => {
      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          handleTimerExpire();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [activeView, timerMode, currentIndex, quizQuestions.length]);

  // Handle timer expiration
  const handleTimerExpire = useCallback(() => {
    if (timerMode === 'flash') {
      // Per-question flash timer expired
      soundEffects.playUrgentTick();

      // If this question wasn't answered, mark it
      setAnswers((prev) => {
        if (!prev[currentIndex]) {
          return {
            ...prev,
            [currentIndex]: {
              selectedOption: null,
              isDoubtful: false,
              timeSpentSeconds: currentRoom?.flashSecondsPerQuestion || 60,
            },
          };
        }
        return prev;
      });

      // Move to next question or finish
      if (currentIndex < quizQuestions.length - 1) {
        setCurrentIndex((i) => i + 1);
        const nextFlashSec = currentRoom ? currentRoom.flashSecondsPerQuestion : 60;
        setSecondsRemaining(nextFlashSec);
        setTotalSeconds(nextFlashSec);
      } else {
        finishQuiz();
      }
    } else {
      // Official total exam timer expired!
      finishQuiz();
    }
  }, [timerMode, currentIndex, quizQuestions.length, currentRoom]);

  // Start Solo Quiz
  const handleStartSoloQuiz = (config: {
    questionCount: number;
    timerMode: TimerMode;
    categoryFilter: UPACategory | 'Semua Materi';
    flashSeconds: number;
    officialMinutes: number;
  }) => {
    setCurrentRoom(null);
    setCurrentUser(null);
    setParticipants([]);

    // Filter questions
    const all = [...MASTER_UPA_DATABASE, ...customQuestions];
    let pool = config.categoryFilter === 'Semua Materi'
      ? all
      : all.filter((q) => q.category === config.categoryFilter);

    if (pool.length === 0) pool = all;

    // Seeded shuffle
    const seed = 'SOLO-' + Date.now();
    const shuffled = shuffleWithSeed(pool, seed).slice(0, config.questionCount);

    setQuizQuestions(shuffled);
    setCurrentIndex(0);
    setAnswers({});
    setTimerMode(config.timerMode);
    setQuizStartTime(Date.now());

    if (config.timerMode === 'official') {
      const totalSec = config.officialMinutes * 60;
      setTotalSeconds(totalSec);
      setSecondsRemaining(totalSec);
    } else {
      const flashSec = config.flashSeconds;
      setTotalSeconds(flashSec);
      setSecondsRemaining(flashSec);
    }

    setActiveView('quiz');
  };

  // Helper to start prepared quiz (for solo & multiplayer)
  const startPreparedQuiz = (room: RoomSettings, seed: string) => {
    const all = [...MASTER_UPA_DATABASE, ...customQuestions];
    let pool = room.categoryFilter === 'Semua Materi'
      ? all
      : all.filter((q) => q.category === room.categoryFilter);

    if (pool.length === 0) pool = all;

    const shuffled = shuffleWithSeed(pool, seed).slice(0, room.questionCount);

    setQuizQuestions(shuffled);
    setCurrentIndex(0);
    setAnswers({});
    setTimerMode(room.timerMode);
    setQuizStartTime(Date.now());

    if (room.timerMode === 'official') {
      const totalSec = room.officialTotalMinutes * 60;
      setTotalSeconds(totalSec);
      setSecondsRemaining(totalSec);
    } else {
      const flashSec = room.flashSecondsPerQuestion;
      setTotalSeconds(flashSec);
      setSecondsRemaining(flashSec);
    }

    setActiveView('quiz');
  };

  // Create Room
  const handleCreateRoom = (settings: RoomSettings, hostName: string) => {
    const hostUser: Participant = {
      id: 'host-' + Date.now(),
      name: hostName,
      isHost: true,
      isReady: true,
      currentQuestionIndex: 0,
      score: 0,
      answeredCount: 0,
      isFinished: false,
      avatarSeed: hostName,
      timeSpentSeconds: 0,
    };

    setCurrentRoom(settings);
    setCurrentUser(hostUser);

    // Initial participants: Host + optional simulated AI study buddies
    const initialPeers: Participant[] = [hostUser];
    if (aiBuddiesEnabled) {
      initialPeers.push(
        {
          id: 'buddy-1',
          name: 'Nadia Safitri, S.H.',
          isHost: false,
          isReady: true,
          currentQuestionIndex: 0,
          score: 0,
          answeredCount: 0,
          isFinished: false,
          avatarSeed: 'Nadia',
          timeSpentSeconds: 0,
        },
        {
          id: 'buddy-2',
          name: 'Dimas Wijaya, S.H.',
          isHost: false,
          isReady: true,
          currentQuestionIndex: 0,
          score: 0,
          answeredCount: 0,
          isFinished: false,
          avatarSeed: 'Dimas',
          timeSpentSeconds: 0,
        }
      );
    }

    setParticipants(initialPeers);

    // Initialize Live Room Chat
    const welcomeMsg: RoomChatMessage = {
      id: 'sys-create-' + Date.now(),
      roomCode: settings.code,
      senderId: 'sys',
      senderName: 'Sistem UPA',
      message: `Ruang "${settings.roomName}" (${settings.code}) aktif. Silakan gunakan fitur obrolan langsung untuk berdiskusi dengan rekan! ⚖️`,
      timestamp: Date.now(),
      isSystem: true,
    };
    const initChat = [welcomeMsg];
    if (aiBuddiesEnabled) {
      initChat.push({
        id: 'msg-nadia-init',
        roomCode: settings.code,
        senderId: 'buddy-1',
        senderName: 'Nadia Safitri, S.H.',
        senderRole: 'peserta',
        message: 'Halo rekan-rekan seangkatan! Salam kenal, mari kita saling menyemangati! ⚖️',
        timestamp: Date.now() + 800,
      });
    }
    setRoomMessages(initChat);
  };

  // Join Room
  const handleJoinRoom = (code: string, userName: string) => {
    // Reconstruct or accept room
    const mockRoom: RoomSettings = {
      code,
      roomName: `Ruang UPA (${code})`,
      hostName: 'Host Penyelenggara',
      questionCount: 20,
      timerMode: 'official',
      categoryFilter: 'Semua Materi',
      flashSecondsPerQuestion: 60,
      officialTotalMinutes: 30,
    };

    const guest: Participant = {
      id: 'guest-' + Date.now(),
      name: userName,
      isHost: false,
      isReady: true,
      currentQuestionIndex: 0,
      score: 0,
      answeredCount: 0,
      isFinished: false,
      avatarSeed: userName,
      timeSpentSeconds: 0,
    };

    setCurrentRoom(mockRoom);
    setCurrentUser(guest);

    const group: Participant[] = [
      {
        id: 'host-demo',
        name: 'Ketua Kelas PKPA',
        isHost: true,
        isReady: true,
        currentQuestionIndex: 0,
        score: 0,
        answeredCount: 0,
        isFinished: false,
        avatarSeed: 'Host',
        timeSpentSeconds: 0,
      },
      guest,
    ];

    if (aiBuddiesEnabled) {
      group.push({
        id: 'buddy-3',
        name: 'Kartika Putri, S.H.',
        isHost: false,
        isReady: true,
        currentQuestionIndex: 0,
        score: 0,
        answeredCount: 0,
        isFinished: false,
        avatarSeed: 'Kartika',
        timeSpentSeconds: 0,
      });
    }

    setParticipants(group);

    // Initialize Room Live Chat
    const joinMsg: RoomChatMessage = {
      id: 'sys-join-' + Date.now(),
      roomCode: code,
      senderId: 'sys',
      senderName: 'Sistem UPA',
      message: `${userName} telah bergabung ke ruangan.`,
      timestamp: Date.now(),
      isSystem: true,
    };
    setRoomMessages([
      {
        id: 'sys-welcome-' + Date.now(),
        roomCode: code,
        senderId: 'sys',
        senderName: 'Sistem UPA',
        message: `Selamat bergabung di Ruang Ujian (${code}).`,
        timestamp: Date.now() - 500,
        isSystem: true,
      },
      joinMsg,
    ]);

    // Broadcast join to other browser tabs
    if (channelRef.current) {
      channelRef.current.postMessage({
        type: 'ROOM_JOIN',
        payload: { roomCode: code, participant: guest },
      });
      channelRef.current.postMessage({
        type: 'CHAT_MESSAGE',
        payload: { roomCode: code, message: joinMsg },
      });
    }
  };

  // Send message in Room Live Chat
  const handleSendChatMessage = (text: string) => {
    if (!currentRoom || !currentUser || !text.trim()) return;
    const newMsg: RoomChatMessage = {
      id: 'msg-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6),
      roomCode: currentRoom.code,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderRole: currentUser.isHost ? 'host' : 'peserta',
      message: text.trim(),
      timestamp: Date.now(),
    };
    setRoomMessages((prev) => [...prev, newMsg]);

    if (channelRef.current) {
      channelRef.current.postMessage({
        type: 'CHAT_MESSAGE',
        payload: { roomCode: currentRoom.code, message: newMsg },
      });
    }
  };

  // Start exam from multiplayer lobby
  const handleStartMultiplayerExam = () => {
    if (!currentRoom) return;
    const seed = currentRoom.code;

    // Broadcast start to other tabs
    if (channelRef.current) {
      channelRef.current.postMessage({
        type: 'START_EXAM',
        payload: { roomCode: currentRoom.code, roomSettings: currentRoom, seed },
      });
    }

    startPreparedQuiz(currentRoom, seed);
  };

  // Leave room
  const handleLeaveRoom = () => {
    setCurrentRoom(null);
    setCurrentUser(null);
    setParticipants([]);
    setRoomMessages([]);
    setChatModalOpen(false);
    setActiveView('home');
  };

  // Option selection
  const handleSelectOption = (key: QuestionOptionKey) => {
    setAnswers((prev) => {
      const existing = prev[currentIndex];
      const updated = {
        ...prev,
        [currentIndex]: {
          selectedOption: key,
          isDoubtful: existing?.isDoubtful || false,
          timeSpentSeconds: (existing?.timeSpentSeconds || 0) + 1,
        },
      };

      // Broadcast score update if in multiplayer
      if (currentRoom && currentUser && channelRef.current) {
        let correctCount = 0;
        quizQuestions.forEach((q, idx) => {
          if (updated[idx]?.selectedOption === q.correctAnswer) {
            correctCount++;
          }
        });
        const scorePct = (correctCount / quizQuestions.length) * 100;
        const answeredCount = Object.keys(updated).length;

        channelRef.current.postMessage({
          type: 'SCORE_UPDATE',
          payload: {
            roomCode: currentRoom.code,
            participantId: currentUser.id,
            score: scorePct,
            answeredCount,
            isFinished: false,
            timeSpentSeconds: Math.floor((Date.now() - quizStartTime) / 1000),
          },
        });
      }

      return updated;
    });

    // If flash timer mode, automatically transition to next question after selecting
    if (timerMode === 'flash') {
      setTimeout(() => {
        if (currentIndex < quizQuestions.length - 1) {
          setCurrentIndex((i) => i + 1);
          const flashSec = currentRoom ? currentRoom.flashSecondsPerQuestion : 60;
          setSecondsRemaining(flashSec);
          setTotalSeconds(flashSec);
        }
      }, 300);
    }
  };

  // Toggle doubtful flag
  const handleToggleDoubtful = () => {
    setAnswers((prev) => {
      const existing = prev[currentIndex];
      return {
        ...prev,
        [currentIndex]: {
          selectedOption: existing?.selectedOption || null,
          isDoubtful: !existing?.isDoubtful,
          timeSpentSeconds: existing?.timeSpentSeconds || 0,
        },
      };
    });
  };

  // Navigate questions
  const handleSelectQuestionIndex = (index: number) => {
    setCurrentIndex(index);
    setMobileGridOpen(false);

    // If flash mode, reset timer for the new question
    if (timerMode === 'flash') {
      const flashSec = currentRoom ? currentRoom.flashSecondsPerQuestion : 60;
      setSecondsRemaining(flashSec);
      setTotalSeconds(flashSec);
    }
  };

  const handleNext = () => {
    if (currentIndex < quizQuestions.length - 1) {
      setCurrentIndex((i) => i + 1);
      if (timerMode === 'flash') {
        const flashSec = currentRoom ? currentRoom.flashSecondsPerQuestion : 60;
        setSecondsRemaining(flashSec);
        setTotalSeconds(flashSec);
      }
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex((i) => i - 1);
      if (timerMode === 'flash') {
        const flashSec = currentRoom ? currentRoom.flashSecondsPerQuestion : 60;
        setSecondsRemaining(flashSec);
        setTotalSeconds(flashSec);
      }
    }
  };

  // Finish quiz & calculate summary
  const finishQuiz = () => {
    const totalDurationSeconds = Math.max(1, Math.floor((Date.now() - quizStartTime) / 1000));
    const totalQ = quizQuestions.length;
    let correct = 0;
    let wrong = 0;
    let doubtful = 0;
    let answered = 0;

    const catStats: Record<UPACategory, { total: number; correct: number }> = {
      'Hukum Acara Perdata': { total: 0, correct: 0 },
      'Hukum Acara Pidana': { total: 0, correct: 0 },
      'Hukum Acara PTUN': { total: 0, correct: 0 },
      'Hukum Acara Peradilan Agama': { total: 0, correct: 0 },
      'Kode Etik Profesi Advokat': { total: 0, correct: 0 },
      'Hukum Acara Mahkamah Konstitusi': { total: 0, correct: 0 },
      'Hukum Acara PHI': { total: 0, correct: 0 },
      'Hukum Acara Arbitrase & APS': { total: 0, correct: 0 },
    };

    quizQuestions.forEach((q, idx) => {
      const ans = answers[idx];
      if (catStats[q.category]) {
        catStats[q.category].total++;
      }

      if (ans?.selectedOption !== null && ans?.selectedOption !== undefined) {
        answered++;
        if (ans.selectedOption === q.correctAnswer) {
          correct++;
          if (catStats[q.category]) catStats[q.category].correct++;
        } else {
          wrong++;
        }
      } else {
        wrong++;
      }

      if (ans?.isDoubtful) {
        doubtful++;
      }
    });

    const scorePercent = totalQ > 0 ? (correct / totalQ) * 100 : 0;
    const passed = scorePercent >= 70; // Standard UPA passing grade is 70%

    const categoryBreakdown = Object.entries(catStats)
      .filter(([_, data]) => data.total > 0)
      .map(([cat, data]) => ({
        category: cat as UPACategory,
        total: data.total,
        correct: data.correct,
        percentage: data.total > 0 ? (data.correct / data.total) * 100 : 0,
      }));

    const summary: QuizSessionSummary = {
      totalQuestions: totalQ,
      answeredCount: answered,
      correctCount: correct,
      wrongCount: wrong,
      doubtfulCount: doubtful,
      unansweredCount: totalQ - answered,
      scorePercent,
      passed,
      totalDurationSeconds,
      categoryBreakdown,
    };

    setQuizSummary(summary);

    // Save full detailed history to userService so the admin and friends can review anytime
    if (authProfile) {
      const questionResults: QuestionResultItem[] = quizQuestions.map((q, idx) => {
        const ans = answers[idx];
        const sel = ans?.selectedOption || null;
        const isCorrect = sel === q.correctAnswer;
        return {
          id: q.id,
          question: q.question,
          category: q.category,
          topicTag: q.topicTag,
          options: q.options,
          correctAnswer: q.correctAnswer,
          userAnswer: sel,
          isCorrect,
          legalBasis: q.explanation.legalBasis,
          summary: q.explanation.summary,
        };
      });

      const examTitle = currentRoom
        ? currentRoom.roomName
        : totalQ === 120
        ? 'Try Out Resmi UPA 2026 (120 Soal)'
        : `Simulasi Mandiri ${totalQ} Soal UPA`;

      userService.saveQuizHistory({
        id: 'hist-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6),
        userId: authProfile.id,
        userName: authProfile.name,
        userEmail: authProfile.email,
        quizTitle: examTitle,
        categoryFilter: currentRoom ? currentRoom.categoryFilter : 'Semua Materi',
        totalQuestions: totalQ,
        score: scorePercent,
        scorePercent,
        passed,
        correctCount: correct,
        wrongCount: wrong,
        doubtfulCount: doubtful,
        unansweredCount: totalQ - answered,
        durationSeconds: totalDurationSeconds,
        timestamp: Date.now(),
        questionResults,
      });
    }

    // Update current user score in participants list
    if (currentUser) {
      setParticipants((prev) =>
        prev.map((p) =>
          p.id === currentUser.id
            ? {
                ...p,
                score: scorePercent,
                answeredCount: answered,
                isFinished: true,
                timeSpentSeconds: totalDurationSeconds,
              }
            : p
        )
      );

      // Broadcast finish to other tabs
      if (channelRef.current && currentRoom) {
        channelRef.current.postMessage({
          type: 'SCORE_UPDATE',
          payload: {
            roomCode: currentRoom.code,
            participantId: currentUser.id,
            score: scorePercent,
            answeredCount: answered,
            isFinished: true,
            timeSpentSeconds: totalDurationSeconds,
          },
        });
      }
    }

    setActiveView('results');
  };

  const currentQ = quizQuestions[currentIndex];
  const currentAns = answers[currentIndex];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors duration-200">
      {/* Top Bar Contract compliant Navigation */}
      <Header
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        activeView={activeView}
        setActiveView={setActiveView}
        soundEnabled={soundEnabled}
        setSoundEnabled={setSoundEnabled}
        isQuizActive={activeView === 'quiz'}
        onExitQuiz={() => {
          if (confirm('Apakah Anda yakin ingin mengakhiri simulasi ini? Skor akan langsung dihitung.')) {
            finishQuiz();
          }
        }}
        onOpenSaveModal={() => setSaveModalOpen(true)}
        currentUser={authProfile}
        onLogout={() => {
          userService.logout();
          setAuthProfile(null);
        }}
        onOpenMonitor={() => setActiveView('monitor')}
        onlineUserCount={onlineUserCount}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        
        {/* VIEW 1: HOME & SETUP */}
        {activeView === 'home' && (
          <QuizSetup
            onStartSoloQuiz={handleStartSoloQuiz}
            onOpenMultiplayer={() => setActiveView('multiplayer')}
            onOpenBank={() => setActiveView('bank')}
            onOpenCheatSheet={() => setActiveView('cheatsheet')}
          />
        )}

        {/* VIEW 2: ACTIVE QUIZ SIMULATION */}
        {activeView === 'quiz' && currentQ && (
          <div className="space-y-4">
            {/* Top Examination Status Bar */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3 sm:p-4 shadow-xs flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <span className="font-legal font-bold text-slate-900 dark:text-white text-sm sm:text-base">
                  Lembar Ujian UPA
                </span>
                <span className="hidden sm:inline-block text-xs text-slate-400">|</span>
                <span className="hidden sm:inline-block text-xs text-slate-500 dark:text-slate-400">
                  {currentRoom ? currentRoom.roomName : 'Simulasi Mandiri'}
                </span>
              </div>

              {/* Countdown Timer with urgency highlight */}
              <div className="flex items-center gap-2">
                <TimerDisplay
                  timerMode={timerMode}
                  secondsRemaining={secondsRemaining}
                  totalSeconds={totalSeconds}
                  onExpire={handleTimerExpire}
                />

                {/* Multiplayer Live Chat Toggle */}
                {currentRoom && (
                  <button
                    type="button"
                    onClick={() => {
                      soundEffects.playClick();
                      setChatModalOpen(!chatModalOpen);
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-amber-300 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/40 text-amber-900 dark:text-amber-200 text-xs font-semibold hover:bg-amber-100 dark:hover:bg-amber-900/60 transition-colors shrink-0"
                    title="Obrolan Langsung Ruangan"
                  >
                    <MessageSquare className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                    <span className="hidden sm:inline">Chat Ruang</span>
                    <span className="px-1.5 py-0.2 rounded-full bg-amber-600 text-white text-[10px] font-mono font-bold">
                      {roomMessages.length}
                    </span>
                  </button>
                )}

                {/* Mobile Grid Toggle Button */}
                <button
                  type="button"
                  onClick={() => setMobileGridOpen(true)}
                  className="md:hidden p-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300"
                  title="Buka Lembar Jawaban"
                >
                  <LayoutGrid className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Split Grid & Question Screen */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
              {/* Question Card (Dominant focal anchor) */}
              <div className="md:col-span-8 lg:col-span-8">
                <QuestionCard
                  question={currentQ}
                  index={currentIndex}
                  totalQuestions={quizQuestions.length}
                  userAnswer={currentAns}
                  onSelectOption={handleSelectOption}
                  onPrev={handlePrev}
                  onNext={handleNext}
                  onToggleDoubtful={handleToggleDoubtful}
                  isFirst={currentIndex === 0}
                  isLast={currentIndex === quizQuestions.length - 1}
                  onFinishQuiz={finishQuiz}
                />
              </div>

              {/* Desktop Question Grid Sidebar (1 to 500 Numbers with Color Status) */}
              <div className="hidden md:block md:col-span-4 lg:col-span-4 sticky top-20">
                <QuestionGrid
                  totalQuestions={quizQuestions.length}
                  currentIndex={currentIndex}
                  answers={answers}
                  onSelectQuestion={handleSelectQuestionIndex}
                  onToggleDoubtful={handleToggleDoubtful}
                  isCurrentDoubtful={currentAns?.isDoubtful || false}
                  onFinishQuiz={finishQuiz}
                />
              </div>
            </div>

            {/* Mobile Bottom-sheet Modal for Question Grid */}
            {mobileGridOpen && (
              <div className="md:hidden fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end justify-center p-0">
                <div className="w-full max-h-[85vh] bg-white dark:bg-slate-900 rounded-t-2xl p-4 shadow-xl border-t border-slate-200 dark:border-slate-800 flex flex-col">
                  <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100 dark:border-slate-800">
                    <span className="font-bold text-sm text-slate-900 dark:text-white">
                      Lembar Nomor Soal (1 - {quizQuestions.length})
                    </span>
                    <button
                      onClick={() => setMobileGridOpen(false)}
                      className="p-1 rounded-md text-slate-500 hover:text-slate-800 dark:hover:text-white"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                  <div className="flex-1 overflow-y-auto">
                    <QuestionGrid
                      totalQuestions={quizQuestions.length}
                      currentIndex={currentIndex}
                      answers={answers}
                      onSelectQuestion={handleSelectQuestionIndex}
                      onToggleDoubtful={handleToggleDoubtful}
                      isCurrentDoubtful={currentAns?.isDoubtful || false}
                      onFinishQuiz={finishQuiz}
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* VIEW 3: MULTIPLAYER LOBBY */}
        {activeView === 'multiplayer' && (
          <MultiplayerLobby
            currentRoom={currentRoom}
            participants={participants}
            currentUser={currentUser}
            onCreateRoom={handleCreateRoom}
            onJoinRoom={handleJoinRoom}
            onStartExam={handleStartMultiplayerExam}
            onLeaveRoom={handleLeaveRoom}
            onToggleAiBuddies={setAiBuddiesEnabled}
            aiBuddiesEnabled={aiBuddiesEnabled}
            roomMessages={roomMessages}
            onSendMessage={handleSendChatMessage}
          />
        )}

        {/* VIEW 4: RESULTS DASHBOARD */}
        {activeView === 'results' && quizSummary && (
          <ResultDashboard
            summary={quizSummary}
            questions={quizQuestions}
            answers={answers}
            onOpenReview={() => setActiveView('review')}
            onRestart={() => {
              if (currentRoom) {
                startPreparedQuiz(currentRoom, currentRoom.code);
              } else {
                setAnswers({});
                setCurrentIndex(0);
                setActiveView('quiz');
              }
            }}
            onNewQuiz={() => setActiveView('home')}
            isMultiplayer={Boolean(currentRoom)}
            participants={participants}
            currentUser={currentUser}
          />
        )}

        {/* VIEW 5: DEEP LEGAL REVIEW */}
        {activeView === 'review' && (
          <ReviewModal
            questions={quizQuestions}
            answers={answers}
            onClose={() => setActiveView('results')}
          />
        )}

        {/* VIEW 6: QUESTION BANK DATABASE MANAGER (500 Questions) */}
        {activeView === 'bank' && (
          <QuestionBankModal
            customQuestions={customQuestions}
            onAddQuestion={(newQ) => setCustomQuestions((prev) => [...prev, newQ])}
          />
        )}

        {/* VIEW 7: QUICK CHEAT SHEET PASAL EMAS */}
        {activeView === 'cheatsheet' && <QuickCheatSheet />}

        {/* VIEW 8: MONITOR PESERTA ONLINE & SELURUH RIWAYAT UJIAN */}
        {activeView === 'monitor' && authProfile && (
          <AdminMonitorView
            currentUser={authProfile}
            onClose={() => setActiveView('home')}
          />
        )}
      </main>

      {/* Clean quiet footer */}
      <footer className="mt-auto border-t border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 py-6 text-center text-xs text-slate-500 dark:text-slate-400">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex flex-col sm:flex-row items-center gap-1 sm:gap-2">
            <span>AdvokatQuiz &copy; 2026 · Simulator UPA Standar PERADI</span>
            <span className="hidden sm:inline text-slate-300 dark:text-slate-700">·</span>
            <span className="text-slate-700 dark:text-slate-300 font-medium">Aplikasi dikembangkan oleh <strong className="text-amber-700 dark:text-amber-400 font-semibold">Ahmad Miftahul Fauzi,S.H.</strong></span>
          </div>
          <div className="flex items-center gap-4 text-[11px]">
            <span>Pasal HIR/RBg</span>
            <span>KUHAP</span>
            <span>UU PTUN</span>
            <span>Kode Etik Advokat</span>
            <span>UU MK</span>
          </div>
        </div>
      </footer>

      {/* Permanent Save & Install Guide Modal */}
      <PermanentSaveModal
        isOpen={saveModalOpen}
        onClose={() => setSaveModalOpen(false)}
      />

      {/* Floating Live Chat Widget for Multiplayer Room */}
      {currentRoom && (
        <div className="fixed bottom-6 right-4 sm:right-6 z-50">
          {chatModalOpen ? (
            <RoomLiveChat
              roomCode={currentRoom.code}
              currentUser={currentUser}
              messages={roomMessages}
              onSendMessage={handleSendChatMessage}
              onClose={() => setChatModalOpen(false)}
              isFloating={true}
            />
          ) : (
            activeView === 'quiz' && (
              <button
                type="button"
                onClick={() => {
                  soundEffects.playClick();
                  setChatModalOpen(true);
                }}
                className="px-4 py-2.5 rounded-full bg-slate-900 dark:bg-amber-600 text-white font-bold text-xs shadow-xl hover:scale-105 active:scale-95 transition-all flex items-center gap-2 border border-slate-700 dark:border-amber-500"
                title="Buka Obrolan Ruang Langsung"
              >
                <div className="relative">
                  <MessageSquare className="w-4 h-4" />
                  <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                </div>
                <span>Chat Ruangan</span>
                {roomMessages.length > 0 && (
                  <span className="px-1.5 py-0.2 rounded-full bg-amber-500 dark:bg-slate-950 text-white text-[10px] font-mono font-bold">
                    {roomMessages.length}
                  </span>
                )}
              </button>
            )
          )}
        </div>
      )}

      {/* Required Email Login Gate for first-time entry */}
      {!authProfile && (
        <LoginGateModal
          onLoginSuccess={(user) => {
            setAuthProfile(user);
          }}
        />
      )}
    </div>
  );
}
