import { UserProfile, UserQuizHistoryRecord, QuestionResultItem } from '../types/auth';

const STORAGE_KEY_CURRENT_USER = 'advokatquiz_current_user_v1';
const STORAGE_KEY_ALL_USERS = 'advokatquiz_all_users_v1';
const STORAGE_KEY_HISTORY = 'advokatquiz_all_history_v1';

// Seed initial study colleagues so the user can immediately experience active presence & history
const INITIAL_SEED_USERS: UserProfile[] = [
  {
    id: 'user-seed-1',
    name: 'Nadia Safitri, S.H.',
    email: 'nadia.safitri@lexlaw.id',
    organization: 'PKPA PERADI DPC Jakarta Pusat',
    role: 'peserta',
    createdAt: Date.now() - 86400000 * 2,
    lastActive: Date.now() - 1000 * 45, // 45 seconds ago (Online)
    isOnline: true,
    currentActivity: 'Sedang Mengerjakan Try Out 120 Soal (Soal 48/120)',
  },
  {
    id: 'user-seed-2',
    name: 'Dimas Wijaya, S.H., M.H.',
    email: 'dimas.wijaya@advokatindo.com',
    organization: 'PKPA PERADI Alumni FH UI',
    role: 'peserta',
    createdAt: Date.now() - 86400000 * 4,
    lastActive: Date.now() - 1000 * 120, // 2 mins ago (Online)
    isOnline: true,
    currentActivity: 'Mempelajari Pembahasan Hukum Acara Perdata',
  },
  {
    id: 'user-seed-3',
    name: 'Reza Maulana, S.H.',
    email: 'reza.maulana@peradi-muda.org',
    organization: 'PKPA Angkatan 2026 Gelombang I',
    role: 'peserta',
    createdAt: Date.now() - 86400000 * 5,
    lastActive: Date.now() - 1000 * 600, // 10 mins ago
    isOnline: false,
    currentActivity: 'Selesai Simulasi Hukum Acara Pidana',
  },
];

const INITIAL_SEED_HISTORY: UserQuizHistoryRecord[] = [
  {
    id: 'hist-seed-1',
    userId: 'user-seed-1',
    userName: 'Nadia Safitri, S.H.',
    userEmail: 'nadia.safitri@lexlaw.id',
    quizTitle: 'Try Out Resmi UPA 2026',
    categoryFilter: 'Semua Materi',
    totalQuestions: 120,
    score: 82.5,
    scorePercent: 82.5,
    passed: true,
    correctCount: 99,
    wrongCount: 21,
    doubtfulCount: 8,
    unansweredCount: 0,
    durationSeconds: 5820, // 97 mins
    timestamp: Date.now() - 3600000 * 4, // 4 hours ago
    questionResults: [
      {
        id: 1,
        question: 'Pada tanggal 21 Desember 2004, dibentuk suatu wadah sebagai wujud nyata dari kesatuan dan persatuan para Advokat Indonesia, yaitu....',
        category: 'Kode Etik Profesi Advokat',
        topicTag: 'Wadah Tunggal Advokat',
        options: [
          { key: 'A', text: 'Persatuan Advokat Indonesia (PERADIN)' },
          { key: 'B', text: 'Himpunan Advokat dan Pengacara Indonesia (HAPI)' },
          { key: 'C', text: 'Perhimpunan Advokat Indonesia (PERADI)' },
          { key: 'D', text: 'Komite Kerja Advokat Indonesia (KKAI)' }
        ],
        correctAnswer: 'C',
        userAnswer: 'C',
        isCorrect: true,
        legalBasis: 'Pasal 32 ayat (4) UU No. 18 Tahun 2003 tentang Advokat.',
        summary: 'PERADI dibentuk oleh 8 organisasi advokat sebagai pemenuhan amanat UU No. 18 Tahun 2003.'
      },
      {
        id: 2,
        question: 'Pasal 21 Undang-Undang Republik Indonesia Nomor 18 Tahun 2003 tentang Advokat mengatur besarnya honorarium berdasarkan....',
        category: 'Kode Etik Profesi Advokat',
        topicTag: 'Honorarium Advokat',
        options: [
          { key: 'A', text: 'Peraturan Pemerintah' },
          { key: 'B', text: 'Undang-undang' },
          { key: 'C', text: 'Organisasi advokat' },
          { key: 'D', text: 'Persetujuan kedua belah pihak' }
        ],
        correctAnswer: 'D',
        userAnswer: 'D',
        isCorrect: true,
        legalBasis: 'Pasal 21 ayat (2) UU No. 18 Tahun 2003 tentang Advokat.',
        summary: 'Besaran honorarium didasarkan pada kesepakatan atau persetujuan yang wajar antara advokat dengan kliennya.'
      },
      {
        id: 35,
        question: 'Apabila sebuah bangunan milik orang lain yang sedang disewakan kepada pihak penyewa dikenakan sita eksekusi, maka pihak yang berhak mengajukan bantahan terhadap sita eksekusi ini adalah...',
        category: 'Hukum Acara Perdata',
        topicTag: 'Perlawanan Pihak Ketiga (Derden Verzet)',
        options: [
          { key: 'A', text: 'Si Penyewa bangunan yang disita dengan upaya hukum Derden Verzet' },
          { key: 'B', text: 'Si Pemilik bangunan yang disita saja' },
          { key: 'C', text: 'Si Pemilik dan si Penyewa bangunan secara bersama-sama' },
          { key: 'D', text: 'Semua orang yang berkepentingan atas bangunan tersebut' }
        ],
        correctAnswer: 'A',
        userAnswer: 'B',
        isCorrect: false,
        legalBasis: 'Pasal 378 Rv jo. Pasal 195 dan Pasal 206 HIR.',
        summary: 'Penyewa sebagai pihak ketiga yang menguasai fisik bangunan berhak mengajukan Derden Verzet.'
      }
    ]
  },
  {
    id: 'hist-seed-2',
    userId: 'user-seed-2',
    userName: 'Dimas Wijaya, S.H., M.H.',
    userEmail: 'dimas.wijaya@advokatindo.com',
    quizTitle: 'Simulasi Terfokus Hukum Acara Perdata',
    categoryFilter: 'Hukum Acara Perdata',
    totalQuestions: 20,
    score: 90,
    scorePercent: 90,
    passed: true,
    correctCount: 18,
    wrongCount: 2,
    doubtfulCount: 1,
    unansweredCount: 0,
    durationSeconds: 1140, // 19 mins
    timestamp: Date.now() - 3600000 * 18, // 18 hours ago
    questionResults: []
  },
  {
    id: 'hist-seed-3',
    userId: 'user-seed-3',
    userName: 'Reza Maulana, S.H.',
    userEmail: 'reza.maulana@peradi-muda.org',
    quizTitle: 'Simulasi Hukum Acara Pidana & KUHAP',
    categoryFilter: 'Hukum Acara Pidana',
    totalQuestions: 20,
    score: 65,
    scorePercent: 65,
    passed: false, // < 70%
    correctCount: 13,
    wrongCount: 7,
    doubtfulCount: 3,
    unansweredCount: 0,
    durationSeconds: 1380, // 23 mins
    timestamp: Date.now() - 3600000 * 28, // yesterday
    questionResults: []
  }
];

class UserService {
  private channel: BroadcastChannel | null = null;

  constructor() {
    if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
      this.channel = new BroadcastChannel('advokatquiz_auth_sync');
    }
  }

  // Get current logged-in user
  public getCurrentUser(): UserProfile | null {
    if (typeof window === 'undefined') return null;
    const raw = localStorage.getItem(STORAGE_KEY_CURRENT_USER);
    if (!raw) return null;
    try {
      return JSON.parse(raw);
    } catch {
      return null;
    }
  }

  // Login or Register User
  public login(name: string, email: string, organization?: string): UserProfile {
    const cleanEmail = email.trim().toLowerCase();
    const cleanName = name.trim();

    // Recognize admin by default email or explicit flag
    const isAdmin = cleanEmail === 'amifaveiro9@gmail.com' || cleanEmail.includes('admin');

    const user: UserProfile = {
      id: 'usr-' + btoa(cleanEmail).replace(/[^a-zA-Z0-9]/g, '').slice(0, 12),
      name: cleanName,
      email: cleanEmail,
      organization: organization?.trim() || 'Calon Advokat Indonesia',
      role: isAdmin ? 'admin' : 'peserta',
      createdAt: Date.now(),
      lastActive: Date.now(),
      isOnline: true,
      currentActivity: 'Di Halaman Utama AdvokatQuiz',
    };

    localStorage.setItem(STORAGE_KEY_CURRENT_USER, JSON.stringify(user));

    // Also register into all users directory
    this.upsertUserDirectory(user);

    // Notify other tabs
    if (this.channel) {
      this.channel.postMessage({ type: 'USER_LOGIN', user });
    }

    return user;
  }

  // Logout
  public logout(): void {
    const currentUser = this.getCurrentUser();
    if (currentUser) {
      currentUser.isOnline = false;
      currentUser.lastActive = Date.now();
      this.upsertUserDirectory(currentUser);
      if (this.channel) {
        this.channel.postMessage({ type: 'USER_LOGOUT', userId: currentUser.id });
      }
    }
    localStorage.removeItem(STORAGE_KEY_CURRENT_USER);
  }

  // Update Activity & Heartbeat
  public updateActivity(activityText: string): void {
    const user = this.getCurrentUser();
    if (!user) return;

    user.currentActivity = activityText;
    user.lastActive = Date.now();
    user.isOnline = true;

    localStorage.setItem(STORAGE_KEY_CURRENT_USER, JSON.stringify(user));
    this.upsertUserDirectory(user);

    if (this.channel) {
      this.channel.postMessage({ type: 'USER_HEARTBEAT', user });
    }
  }

  // Get all registered / active users
  public getAllUsers(): UserProfile[] {
    if (typeof window === 'undefined') return INITIAL_SEED_USERS;
    const raw = localStorage.getItem(STORAGE_KEY_ALL_USERS);
    let list: UserProfile[] = [];
    if (raw) {
      try {
        list = JSON.parse(raw);
      } catch {
        list = [];
      }
    }

    // Merge with seeds if empty
    if (list.length === 0) {
      list = [...INITIAL_SEED_USERS];
      localStorage.setItem(STORAGE_KEY_ALL_USERS, JSON.stringify(list));
    }

    // Update isOnline status based on lastActive threshold (active in last 5 minutes)
    const now = Date.now();
    return list.map((u) => ({
      ...u,
      isOnline: now - u.lastActive <= 5 * 60 * 1000,
    }));
  }

  // Save new user or update existing
  private upsertUserDirectory(user: UserProfile): void {
    const all = this.getAllUsers();
    const index = all.findIndex((u) => u.email === user.email || u.id === user.id);
    if (index >= 0) {
      all[index] = { ...all[index], ...user, lastActive: Date.now() };
    } else {
      all.unshift(user);
    }
    localStorage.setItem(STORAGE_KEY_ALL_USERS, JSON.stringify(all));
  }

  // Record an exam / quiz attempt
  public saveQuizHistory(record: UserQuizHistoryRecord): void {
    const all = this.getAllHistory();
    all.unshift(record);
    localStorage.setItem(STORAGE_KEY_HISTORY, JSON.stringify(all));

    // Update user's last activity
    this.updateActivity(`Selesai mengerjakan ${record.quizTitle} (Skor: ${record.scorePercent.toFixed(1)}%)`);

    if (this.channel) {
      this.channel.postMessage({ type: 'NEW_HISTORY_RECORD', record });
    }
  }

  // Get all quiz history across all friends
  public getAllHistory(): UserQuizHistoryRecord[] {
    if (typeof window === 'undefined') return INITIAL_SEED_HISTORY;
    const raw = localStorage.getItem(STORAGE_KEY_HISTORY);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY_HISTORY, JSON.stringify(INITIAL_SEED_HISTORY));
      return [...INITIAL_SEED_HISTORY];
    }
    try {
      return JSON.parse(raw);
    } catch {
      return [...INITIAL_SEED_HISTORY];
    }
  }

  // Export history to CSV
  public exportHistoryCsv(historyList: UserQuizHistoryRecord[]): void {
    const headers = [
      'ID',
      'Tanggal',
      'Nama Peserta',
      'Email',
      'Paket Ujian',
      'Materi',
      'Total Soal',
      'Skor Akhir',
      'Akurasi (%)',
      'Status Kelulusan',
      'Benar',
      'Salah',
      'Ragu-ragu',
      'Durasi (Menit)'
    ];

    const rows = historyList.map((h) => [
      h.id,
      new Date(h.timestamp).toLocaleString('id-ID'),
      `"${h.userName.replace(/"/g, '""')}"`,
      h.userEmail,
      `"${h.quizTitle.replace(/"/g, '""')}"`,
      `"${h.categoryFilter.replace(/"/g, '""')}"`,
      h.totalQuestions,
      h.score.toFixed(1),
      h.scorePercent.toFixed(0),
      h.passed ? 'LULUS' : 'TIDAK LULUS',
      h.correctCount,
      h.wrongCount,
      h.doubtfulCount,
      Math.round(h.durationSeconds / 60)
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `riwayat_ujian_advokatquiz_${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }
}

export const userService = new UserService();
